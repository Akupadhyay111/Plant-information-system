#include <iostream>
int main(){std::cout<<"Plant Nursery Project Ready";return 0;}